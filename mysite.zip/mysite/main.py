from website import CreateApp
app = CreateApp()
app.run()